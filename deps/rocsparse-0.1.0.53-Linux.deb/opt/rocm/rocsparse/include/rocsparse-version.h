/* ************************************************************************
 * Copyright 2018 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/*!\file
 * \brief rocsparse-version.h provides the configured version and settings
 */

#pragma once
#ifndef _ROCSPARSE_VERSION_H_
#define _ROCSPARSE_VERSION_H_

// clang-format off
#define ROCSPARSE_VERSION_MAJOR 0
#define ROCSPARSE_VERSION_MINOR 1
#define ROCSPARSE_VERSION_PATCH 0
#define ROCSPARSE_VERSION_TWEAK 0
// clang-format on

#endif // _ROCSPARSE_VERSION_H_
